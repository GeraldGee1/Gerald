const { reply } = require('./_helper');
module.exports = async (sock, chatId, message) => {
    await reply(sock, chatId, `📦 *ᬊ͜͡𝙈𝙧ܓRUTHLESSNESS-MD Repository*\n━━━━━━━━━━━━\n🤖 Bot: *ᬊ͜͡𝙈𝙧ܓRUTHLESSNESS-MD*\n📝 Version: *2.0*\n⚡ Commands: *100+*\n👤 Author: *Scotty*\n\n_ᬊ͜͡𝙈𝙧ܓRUTHLESSNESS-MD©_`, message);
};
