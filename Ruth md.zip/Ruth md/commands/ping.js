const { reply } = require('./_helper');
module.exports = async (sock, chatId, message) => {
    const start = Date.now();
    await sock.sendMessage(chatId, { text: '💀 *Pinging...*' }, { quoted: message });
    const ms = Date.now() - start;
    const bar = ms<100?'🔴 Lethal':ms<300?'🟡 Fast':'🟢 Alive';
    await reply(sock, chatId,
`💀 *RUTHLESSNESS-MD*
━━━━━━━━━━━━━━━━
⚡ Speed: *${ms}ms*
📶 Status: ${bar}
☠️ Bot: *ALIVE*`, message);
};
